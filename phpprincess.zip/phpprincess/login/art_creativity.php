<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['email'])) {
    header("Location: signin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drawing Fun for Kids</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .container {
            padding: 20px;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        canvas {
            border: 1px solid #ddd;
            margin-top: 20px;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const canvas = document.getElementById('drawingCanvas');
            const ctx = canvas.getContext('2d');
            let drawing = false;

            canvas.addEventListener('mousedown', startDrawing);
            canvas.addEventListener('mouseup', stopDrawing);
            canvas.addEventListener('mousemove', draw);
            canvas.addEventListener('touchstart', startDrawing);
            canvas.addEventListener('touchend', stopDrawing);
            canvas.addEventListener('touchmove', draw);

            function startDrawing(event) {
                drawing = true;
                ctx.beginPath();
                ctx.moveTo(event.clientX - canvas.offsetLeft, event.clientY - canvas.offsetTop);
                event.preventDefault();
            }

            function stopDrawing(event) {
                drawing = false;
                event.preventDefault();
            }

            function draw(event) {
                if (!drawing) return;
                ctx.lineTo(event.clientX - canvas.offsetLeft, event.clientY - canvas.offsetTop);
                ctx.strokeStyle = "#000000";
                ctx.lineWidth = 2;
                ctx.stroke();
                event.preventDefault();
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <h1>Drawing Fun for Kids</h1>
        <canvas id="drawingCanvas" width="800" height="600"></canvas>
    </div>
</body>
</html>
