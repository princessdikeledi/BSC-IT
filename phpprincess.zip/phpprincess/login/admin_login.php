<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(isset($_POST['adminLogin'])) {
    $admin_email = $_POST['email'];
    $admin_password = $_POST['password'];
    $admin_password = md5($admin_password);

    $sql = "SELECT * FROM admins WHERE email='$admin_email' and password='$admin_password'";
    $result = $conn->query($sql);

    if($result->num_rows > 0) {
        $_SESSION['admin_email'] = $admin_email;
        header("Location: admin_dashboard.php");
    } else {
        echo "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Admin Login</h1>
        <form method="post" action="admin_login.php">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="adminLogin">Login</button>
        </form>
    </div>
</body>
</html>
