<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['email'])) {
    header("Location: signin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Math Fun for Kids</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .container {
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .quiz {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }
        h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .question {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .answer {
            font-size: 16px;
            color: #007BFF;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Easy Math Quiz Questions for Kids</h1>
        <div class="quiz">
            <h2>Perfect for morning classroom routine and lunchbox notes, our simple math questions will check kids’ basic arithmetic skills & geometrical concepts.</h2>
            <div class="question">
                <strong>1. Which shape has three corners?</strong>
                <p class="answer">Answer: Triangle!</p>
            </div>
            <div class="question">
                <strong>2. Which number does the Roman numeral “X” represent?</strong>
                <p class="answer">Answer: Number 10!</p>
            </div>
            <div class="question">
                <strong>3. Which number has the same number of letters in its spelling as its meaning?</strong>
                <p class="answer">Answer: Four!</p>
            </div>
            <div class="question">
                <strong>4. Which shape has infinite lines of symmetry?</strong>
                <p class="answer">Answer: Circle!</p>
            </div>
            <div class="question">
                <strong>5. How much is a decade?</strong>
                <p class="answer">Answer: 10 years!</p>
            </div>
            <div class="question">
                <strong>6. How much is one tonne?</strong>
                <p class="answer">Answer: 1000 Kg!</p>
            </div>
            <div class="question">
                <strong>7. What is the current number system called?</strong>
                <p class="answer">Answer: Hindu-Arabic Numeral system!</p>
            </div>
            <div class="question">
                <strong>8. What are whole numbers?</strong>
                <p class="answer">Answer: Whole numbers are real positive integers including zero!</p>
            </div>
            <div class="question">
                <strong>9. How much will be 2X2X1X0X2X3?</strong>
                <p class="answer">Answer: Zero!</p>
            </div>
            <div class="question">
                <strong>10. How many hours are there in a day?</strong>
                <p class="answer">Answer: 24 hours!</p>
            </div>
            <div class="question">
                <strong>11. What is the metric unit of mass?</strong>
                <p class="answer">Answer: Kilogram!</p>
            </div>
            <div class="question">
                <strong>12. Which number becomes even when you take away one letter from it?</strong>
                <p class="answer">Answer: Seven!</p>
            </div>
            <div class="question">
                <strong>13. Which number has the same square root as its cube?</strong>
                <p class="answer">Answer: One!</p>
            </div>
            <div class="question">
                <strong>14. Which is the largest two-digit prime number?</strong>
                <p class="answer">Answer: 97!</p>
            </div>
        </div>
    </div>
</body>
</html>
