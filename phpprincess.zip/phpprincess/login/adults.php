<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About the Platform for Parents</title>
    <style>
        /* Adults Page Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .adults-container {
            max-width: 900px;
            background-color: #ffffff;
            padding: 40px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin: 20px;
        }

        .adults-title {
            font-size: 2.5em;
            color: #333;
            text-align: center;
            margin-bottom: 20px;
            font-family: 'Georgia', serif;
        }

        .section {
            margin-bottom: 30px;
        }

        .section h2 {
            font-size: 1.8em;
            color: #4CAF50;
            margin-bottom: 10px;
        }

        .section p {
            font-size: 1.1em;
            color: #555;
            line-height: 1.6;
        }

        /* Emphasis box for highlighting features */
        .emphasis-box {
            background-color: #e7f3e7;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #4CAF50;
            margin: 20px 0;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

    <div class="adults-container">
        <h1 class="adults-title">Welcome to Kids Foundation Phase Learning</h1>

        <div class="section">
            <h2>About the Platform</h2>
            <p>Our platform is designed to support children's foundational learning journey in a fun and interactive way. We provide a range of educational activities and resources that are carefully crafted to build literacy, math skills, and general knowledge in young learners.</p>
        </div>

        <div class="section">
            <h2>For Parents and Guardians</h2>
            <p>We understand that as a parent or guardian, you want to play an active role in your child's education. Our platform offers tools and insights to help you monitor your child’s progress, track their strengths, and identify areas where they may need extra support.</p>
        </div>

        <div class="section emphasis-box">
            <h2>Key Features for Parents</h2>
            <ul>
                <li><strong>Progress Tracking:</strong> Keep an eye on your child’s learning milestones and achievements.</li>
                <li><strong>Activity Reports:</strong> Access detailed reports on the activities your child completes.</li>
                <li><strong>Educational Insights:</strong> Get recommendations on activities to support your child’s growth.</li>
                <li><strong>Interactive Learning:</strong> Encourage your child’s engagement with fun, educational games and quizzes.</li>
            </ul>
        </div>

        <div class="section">
            <h2>Why Choose Us?</h2>
            <p>Our platform offers a safe, secure, and supportive environment for children to explore learning. All content is carefully curated to ensure age-appropriateness and quality. We’re here to make learning enjoyable and accessible for young minds, while empowering you to be an informed and involved participant in their education.</p>
        </div>
    </div>
</body>
</html>
