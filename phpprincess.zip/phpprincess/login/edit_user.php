<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit();
}

if(isset($_POST['updatePassword'])) {
    $id = $_POST['id'];
    $newPassword = md5($_POST['password']);

    $updateQuery = "UPDATE users SET password='$newPassword' WHERE id='$id'";
    if($conn->query($updateQuery) === TRUE) {
        echo "Password updated successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$id = $_GET['id'];
$user = $conn->query("SELECT * FROM users WHERE id='$id'")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Edit User</h1>
        <form method="post" action="edit_user.php">
            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
            <p>Email: <?php echo $user['email']; ?></p>
            <input type="password" name="password" placeholder="New Password" required>
            <button type="submit" name="updatePassword">Update Password</button>
        </form>
    </div>
</body>
</html>
