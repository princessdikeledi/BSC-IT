<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['email'])) {
    header("Location: signin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reading Fun Stories</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .container {
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .story {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }
        h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Fur and Feathers</h1>
        <div class="story">
            <h2>Illustrated By: Elizabeth Roca</h2>
            <p>THE PRIDE AND JOY OF MAMA OSTRICH were her two baby chicks, hatched from her very own eggs.</p>
            <p>One day, when Mama Ostrich came back home from getting food for her two dear chicks, she looked and looked. But she could not find her chicks anywhere!</p>
            <p>Then - oh my! What did she see but lion tracks on the ground! And right next to those tracks were her two-footed chicks’ tracks! Sore with fear, Mama Ostrich knew that she must find her babies. And so she followed the lion tracks.</p>
            <p>The tracks led into the woods and ended up at a cave. Mama Ostrich stepped up to the opening of the cave and looked in. There were her own dear chicks – in the arms of Mama Lion!</p>
            <p>“What are you doing with my chicks?” cried Mama Ostrich. “Give them back to me at once!”</p>
            <p>“What do you mean your chicks?” Mama Lion rose her head and growled. “These are my cubs – that is plain to see!”</p>
            <p>“It’s not at all plain to see,” said Mama Ostrich. “Those are chicks — ostrich chicks — and I’m an ostrich and you’re a lion!”</p>
            <p>“Is that so?” Mama Lion said with a snarl. “Then you will have no problem finding any other animal who agrees with you. I dare you! Find any animal at all that will look me in the eye and tell me that these are not my cubs. Do that, and I will give them back to you.” Mama Lion raised her big lion head and roared a wild roar.</p>
            <p>Mama Ostrich quickly ran off to the woods. She must tell each and every animal that she was calling a meeting to talk about this terrible crime.</p>
            <p>When she came to the home of the Mongoose and told him her sad story, Mongoose thought and thought. Then he had an idea.</p>
            <p>He said she should go to an ant-hill that was deep in the woods. This ant-hill was so high it more tall than many animals. She should dig a hole in front of that ant-hill. And she should keep digging until the hole came back up behind the ant-hill.</p>
            <p>That was a very odd thing to do. "Why?" said Mama Ostrich. "I am very busy." </p>
            <p>"Listen," said Mongoose. He said the hole must come up behind the ant-hill, where no one could see it. When she was done digging the hole, she should tell all the animals in the woods — and Mama Lion, too — to come to that very ant-hill at sunset.</p>
            <p>And so Mama Ostrich went to the ant-hill and dug the hole. She went about to tell all the animals to meet her there at sunset that very night.</p>
            <p>When all the animals were at the ant-hill, she told them how Mama Lion had taken away her dear, sweet chicks. The zebras and antelopes and all the other animals looked at the chicks held by Mama Lion, and they nodded.</p>
            <p>But when Mama Ostrich said she needed just one animal to look Mama Lion in the eye and tell her that she was not the mother of the chicks, each and every animal in the meeting looked down at the ground. One by one when each animal was asked, each animal said in a soft whisper that the little ones belonged to Mama Lion, and there was no question about that.</p>
            <p>When it came to Mongoose, he cried out, “Have you ever seen a mama with fur with babies that had feathers? Think of what you are saying! Mama Lion has fur! The chicks have feathers! They belong to the ostrich!”</p>
            <p>Then Mongoose jumped down the hole in front of the ant-hill. Down, down the hole he went, to where it came out the other end, and quickly he ran off into the woods before anyone could see him run. Mama Lion tried to leap after him when Mongoose had jumped down the hole, but he was too fast. And when Mama Lion went after Mongoose, the two ostrich chicks were freed! Of course, they ran right into their mother’s open wings.</p>
        </div>
    </div>
</body>
</html>
