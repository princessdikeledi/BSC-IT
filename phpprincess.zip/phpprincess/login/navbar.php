<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <style>
        nav {
            position: fixed;
            top: 0;
            width: 100%;
            background-color:#42a3fb ; 
            padding: 1em 0;
            z-index: 1000; 
            display: flex;
            justify-content: center;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 2.5em; 
        }
        
        nav ul li {
            display: inline;
        }

        nav ul li a {
            color: #fff; 
            text-decoration: none;
            font-weight: bold;
            padding: 0.5em 1em;
            transition: background-color 0.3s; 
        }
       
        nav ul li a:hover {
            background-color: #fb9242; /* Slightly lighter on hover */
            border-radius: 5px; /* Rounds link edges on hover */
        }

        /* Adds padding to the body content to prevent overlap with fixed navbar */
        body {
            padding-top: 3em; /* Space for navbar */
            font-family: Arial, sans-serif;
        }

        /* Footer Styling */
        footer {
            background-color: #f0f0d0; /* Light gray background */
            padding: 1em 0;
            text-align: center;
            position: fixed;
            width: 100%;
            height:30px;
            padding-top:-300px;
            bottom: 0; /* Stick to the bottom */
            left: 0;
            font-family: Arial, sans-serif;
            color: #333; /* Darker text color */
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="kids.php">Kids</a></li>
            <li><a href="adults.php">Adults</a></li>
            <li><a href="signin.php">Sign In</a></li>
            <li><a href="index.php">Sign Up</a></li>
        </ul>
    </nav>

    <!-- Add your body content here -->

    <footer>
        <p>&copy; 2024 Kids Learning Platform. All rights reserved.</p>
        <p>Contact us: <a href="mailto:info@kidslearningplatform.com">info@kidslearningplatform.com</a></p>
    </footer>
</body>
</html>
