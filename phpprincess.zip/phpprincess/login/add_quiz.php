<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit();
}

if(isset($_POST['addQuiz'])) {
    $title = $_POST['title'];
    $reading_material_id = $_POST['reading_material'];
    $questions = $_POST['questions'];

    $insertQuery = "INSERT INTO quizzes (title, reading_material_id, questions) 
                    VALUES ('$title', '$reading_material_id', '$questions')";
    if($conn->query($insertQuery) === TRUE) {
        echo "Quiz added successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$materials = $conn->query("SELECT * FROM reading_materials");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Quiz</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Add Quiz</h1>
        <form method="post" action="add_quiz.php">
            <input type="text" name="title" placeholder="Title" required>
            <select name="reading_material">
                <?php while($material = $materials->fetch_assoc()): ?>
                    <option value="<?php echo $material['id']; ?>"><?php echo $material['title']; ?></option>
                <?php endwhile; ?>
            </select>
            <textarea name="questions" placeholder="Questions" required></textarea>
            <button type="submit" name="addQuiz">Add Quiz</button>
        </form>
    </div>
</body>
</html>
