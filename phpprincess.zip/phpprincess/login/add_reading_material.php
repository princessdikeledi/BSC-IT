<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit();
}

if(isset($_POST['addMaterial'])) {
    $title = $_POST['title'];
    $type = $_POST['type'];
    $grade_id = $_POST['grade'];
    $content = $_POST['content'];

    $insertQuery = "INSERT INTO reading_materials (title, type, grade_id, content) 
                    VALUES ('$title', '$type', '$grade_id', '$content')";
    if($conn->query($insertQuery) === TRUE) {
        echo "Reading material added successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$grades = $conn->query("SELECT * FROM grades");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Reading Material</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>Add Reading Material</h1>
        <form method="post" action="add_reading_material.php">
            <input type="text" name="title" placeholder="Title" required>
            <select name="type">
                <option value="boy">Boy</option>
                <option value="girl">Girl</option>
            </select>
            <select name="grade">
                <?php while($grade = $grades->fetch_assoc()): ?>
                    <option value="<?php echo $grade['id']; ?>"><?php echo $grade['grade_name']; ?></option>
                <?php endwhile; ?>
            </select>
            <textarea name="content" placeholder="Content" required></textarea>
            <button type="submit" name="addMaterial">Add Material</button>
        </form>
    </div>
</body>
</html>
