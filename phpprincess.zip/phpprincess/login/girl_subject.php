<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Girl Category - Kids Learning Platform</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        body {
            padding-top: 3em;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9; /* Light background for better contrast */
        }
        .container {
            width: 90%; /* Set container width to 90% */
            max-width: 1200px; /* Optional: limit maximum width for larger screens */
            margin: 0 auto; /* Center container */
            padding: 20px; /* Add padding for better spacing */
            text-align: center;
        }
        h1 {
            font-size: 48px; /* Increase header font size */
            font-weight: bold;
            margin-bottom: 30px; /* Space below header */
        }
        .row {
            display: flex; /* Use flexbox for layout */
            justify-content: center; /* Center the columns */
            margin: 0 -10px; /* Adjust margins to fit columns */
            flex-wrap: wrap; /* Allow wrapping to next line if necessary */
        }
        .column {
            flex: 23%; /* Adjust width of columns */
            padding: 10px; /* Add padding between columns */
            box-sizing: border-box; /* Include padding in width */
        }
        .column img {
            width: 100%; /* Make images responsive */
            border-radius: 10px; /* Rounded corners for images */
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: transform 0.3s; /* Smooth transition for hover effect */
        }
        .column img:hover {
            transform: scale(1.1); /* Scale image on hover */
        }
        .description {
            font-size: 22px; /* Increase description font size */
            font-weight: bold;
            text-align: center; /* Center text under images */
            margin-top: 10px; /* Space above description */
        }
        /* Centered Logout link styling */
        .logout {
            text-align: center; 
            margin-top: 20px;
            font-size: 20px; /* Increase logout font size */
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Welcome to the Girl's Learning Zone!</h1>
    
    <div class="row">
        <div class="column">
            <a href="reading_material.php">
                <img src="../reading.jpg" alt="Reading Time">
                <p class="description">Reading Time<br>Discover enchanting stories and expand your vocabulary!</p>
            </a>
        </div>
        <div class="column">
            <a href="math_fun.php">
                <img src="../math.jpg" alt="Math Fun">
                <p class="description">Math Fun<br>Have fun with numbers and tackle exciting puzzles!</p>
            </a>
        </div>
        <div class="column">
            <a href="art_creativity.php">
                <img src="../art.jpg" alt="Art & Creativity">
                <p class="description">Art & Creativity<br>Express yourself through drawing, coloring, and creativity!</p>
            </a>
        </div>
        <div class="column">
            <a href="science_adventure.php">
                <img src="../science.jpg" alt="Science Adventure">
                <p class="description">Science Adventure<br>Embark on a journey to explore scientific wonders!</p>
            </a>
        </div>
    </div>
</div>

<!-- Centered Logout link -->
<div class="logout">
    <a href="logout.php">Logout</a>
</div>

</body>
</html>
