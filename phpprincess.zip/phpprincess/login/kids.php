<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kids' Learning Adventures</title>
    <style>
        /* Kids Page Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #FFEB3B; /* Bright yellow for a cheerful look */
        }

        .kids-container {
            text-align: center;
            padding: 20px;
            max-width: 1000px;
            margin: 20px auto;
        }

        .kids-title {
            font-size: 3em;
            font-family: 'Comic Sans MS', cursive, sans-serif;
            color: #FF6347; /* Tomato color for a fun vibe */
            margin-bottom: 20px;
        }

        .kids-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .kid-card {
            background-color: #FFFACD; /* Light pastel color */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            width: 200px;
            padding: 15px;
            text-align: center;
            font-family: 'Comic Sans MS', cursive, sans-serif;
        }

        .kid-card img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .kid-card h2 {
            font-size: 1.5em;
            color: #4CAF50; /* Bright green */
            margin: 10px 0;
        }

        .kid-card p {
            font-size: 1.1em;
            color: #555;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

    <div class="kids-container">
        <h1 class="kids-title">Kids' Learning Adventures!</h1>
        <div class="kids-cards">
            <!-- Kid Card 1 -->
            <div class="kid-card">
                <img src="../reading.jpg" alt="Reading Time">
                <h2>Reading Time</h2>
                <p>Explore magical stories and learn new words!</p>
            </div>
            <!-- Kid Card 2 -->
            <div class="kid-card">
                <img src="../Math.jpg" alt="Math Fun">
                <h2>Math Fun</h2>
                <p>Play with numbers and solve fun puzzles!</p>
            </div>
            <!-- Kid Card 3 -->
            <div class="kid-card">
                <img src="../Art.jpg" alt="Art & Creativity">
                <h2>Art & Creativity</h2>
                <p>Draw, color, and let your imagination run wild!</p>
            </div>
            <!-- Kid Card 4 -->
            <div class="kid-card">
                <img src="../Science.jpg" alt="Science Adventure">
                <h2>Science Adventure</h2>
                <p>Discover the wonders of the world around us!</p>
            </div>
        </div>
    </div>
</body>
</html>
