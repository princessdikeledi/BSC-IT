<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['email'])) {
    header("Location: signin.php");
    exit();
}

$email = $_SESSION['email'];
$user = $conn->query("SELECT id FROM users WHERE email='$email'")->fetch_assoc();
$user_id = $user['id'];

$progress = $conn->query("SELECT reading_materials.title, grades.grade_name, progress.status
    FROM progress
    JOIN reading_materials ON progress.reading_material_id = reading_materials.id
    JOIN grades ON reading_materials.grade_id = grades.id
    WHERE progress.user_id='$user_id'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Progress</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        body {
            padding-top: 3em;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Parent Progress Dashboard</h1>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Grade</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $progress->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['grade_name']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
