<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");

if(!isset($_SESSION['email'])) {
    header("Location: signin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fun Science Facts for Kids</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .container {
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .fact {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }
        h2 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .fact p {
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Fun Science Facts for Kids</h1>
        <div class="fact">
            <h2>Fact 1: Water Can Boil and Freeze at the Same Time</h2>
            <p>Water can boil and freeze at the same time due to a phenomenon called the "triple point." This occurs when the temperature and pressure are just right for the three phases (gas, liquid, and solid) of a substance to coexist in thermodynamic equilibrium.</p>
        </div>
        <div class="fact">
            <h2>Fact 2: Bananas Are Radioactive</h2>
            <p>Bananas contain potassium, and a small fraction of potassium is radioactive. But don’t worry; it’s perfectly safe to eat bananas, as the radiation level is extremely low!</p>
        </div>
        <div class="fact">
            <h2>Fact 3: Honey Never Spoils</h2>
            <p>Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still perfectly good to eat. Honey’s low water content and acidic nature make it difficult for bacteria to grow.</p>
        </div>
        <div class="fact">
            <h2>Fact 4: A Day on Venus Is Longer Than a Year on Venus</h2>
            <p>Venus has a very slow rotation on its axis, taking about 243 Earth days to complete one rotation. However, it takes only about 225 Earth days for Venus to orbit the Sun. Therefore,