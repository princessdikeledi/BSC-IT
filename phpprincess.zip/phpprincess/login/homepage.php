<?php include 'navbar.php'; ?>
<?php
session_start();
include("connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kids Learning Platform</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        body {
            padding-top: 3em;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9; /* Light background for better contrast */
        }
        .container {
            width: 90%; /* Set container width to 90% */
            max-width: 1200px; /* Optional: limit maximum width for larger screens */
            margin: 0 auto; /* Center container */
            padding: 20px; /* Add padding for better spacing */
            text-align: center;
        }
        h1 {
            font-size: 48px; /* Increase header font size */
            font-weight: bold;
            margin-bottom: 30px; /* Space below header */
        }
        .row {
            display: flex; /* Use flexbox for layout */
            justify-content: center; /* Center the columns */
            margin: 0 -10px; /* Adjust margins to fit columns */
            flex-wrap: wrap; /* Allow wrapping to next line if necessary */
        }
        .column {
            flex: 23%; /* Adjust width of columns */
            padding: 10px; /* Add padding between columns */
            box-sizing: border-box; /* Include padding in width */
        }
        .column img {
            width: 100%; /* Make images responsive */
            border-radius: 10px; /* Rounded corners for images */
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: transform 0.3s; /* Smooth transition for hover effect */
        }
        .column img:hover {
            transform: scale(1.1); /* Scale image on hover */
        }
        .description {
            font-size: 22px; /* Increase description font size */
            font-weight: bold;
            text-align: center; /* Center text under images */
            margin-top: 10px; /* Space above description */
        }
        /* Centered Logout link styling */
        .logout {
            text-align: center; 
            margin-top: 20px;
            font-size: 20px; /* Increase logout font size */
            font-weight: bold;
        }
        /* Style for logout button */
        .logout-link {
            display: inline-block;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .logout-link:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Hello 
    <?php
        if(isset($_SESSION['email'])){
            $email = $_SESSION['email'];
            $query = mysqli_query($conn, "SELECT * FROM `users` WHERE email='$email'");
            if(!$query) {
                echo "Error: " . mysqli_error($conn); 
            } else {
                while($row = mysqli_fetch_array($query)){
                    echo $row['firstName'] . ' ' . $row['lastName'];
                }
            }
        }
    ?> are you a?</h1>
    
    <div class="row">
        <div class="column">
            <a href="boy_subject.php">
                <img src="../boy.jpg" alt="Boy">
                <p class="description">Boy</p>
            </a>
        </div>
        <div class="column">
            <a href="girl_subject.php">
                <img src="../girl.jpg" alt="Girl">
                <p class="description">Girl</p>
            </a>
        </div>
        <div class="column">
            <a href="parentprogress.php">
                <img src="../parent.jpg" alt="Parent">
                <p class="description">Parent</p>
            </a>
        </div>
    </div>
</div>

<!-- Centered Logout button -->
<div class="logout">
    <a href="logout.php" class="logout-link">Logout</a>
</div>

</body>
</html>
