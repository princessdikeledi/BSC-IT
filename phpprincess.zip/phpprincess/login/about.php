<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Kids Foundation Phase Learning</title>
    <style>
        /* About Page Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f5f5f5;
        }

        .about-container {
            text-align: center;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .about-title {
            font-size: 3em;
            font-family: 'Comic Sans MS', cursive, sans-serif;
            color: #FF6347; /* Fun, bright color */
            margin-bottom: 20px;
        }

        .about-text {
            font-size: 1.5em;
            line-height: 1.6;
            color: #333;
            font-family: 'Comic Sans MS', cursive, sans-serif;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

    <div class="about-container">
        <h1 class="about-title">About Us!</h1>
        <p class="about-text">
            Welcome to <strong>Kids Foundation Phase Learning</strong> – where learning is fun, exciting, and just for you! 🎉<br><br>
            We’re here to help kids like YOU learn to read, explore amazing stories, and have a blast with every lesson! 🧑‍🏫📚<br><br>
            For all the parents and adults out there, you get a special role too! You can see how your little ones are growing and learning along the way. 🌟<br><br>
            Ready to start? Dive in and join us on an awesome learning adventure!
        </p>
    </div>

</body>
</html>
