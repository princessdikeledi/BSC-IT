<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Kids Foundation Phase Learning</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container" id="home">
        <h1>Welcome to Kids Foundation Phase Learning</h1>
        <p>This platform is designed to provide educational resources for children of all ages. Our goal is to create an engaging and interactive learning experience.</p>
        <p>We offer a variety of content for kids and adults. Explore our sections to find activities, tutorials, and more!</p>
        <a href="kids.php">Learn More for Kids</a>
        <a href="adults.php">Learn More for Adults</a>
    </div>
</body>
</html>
