//Displaying the text
const display = document.getElementById("inputbox");

//calculator buttons
const buttons = document.querySelectorAll("button");

//adding the event listerners to all buttons

    buttons.forEach(function(button){
        button.addEventListener("click",function(){
            
            const buttontext = button.textContent;

            //handling different button clicks
            if(buttontext === "AC"){
                display.value = "0";
            
            }
            else if(buttontext === "DEL") {
               display.value = display.value.slice(0, -1);
               if(display.value === ""){
                display.value = "0";
               }
            }

            else if(buttontext === "="){
                try{
                    display.value = eval(display.value);
                }
                catch(error){
                    display.value ="error";
                }
            }

            else {
                //for the button to display
                display.value =
                display.value === "0"? buttontext : display.value + buttontext;
            }
        }
            );
            
            document.getElementById("plusMinus").addEventListener("click",function(){
                display.value = parseFloat(display.value)* -1;

            });   
            });
